<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Status Masjid & Musholla — PDM Kota Batam</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.9.0/dist/tabler-icons.min.css"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
@vite('resources/css/app.css')
@include('shared.styles')
<style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body>
<div class="app-shell">

  @include('superadmin.sidebar', ['activeNav' => 'status-masjid'])

  <div class="main-shell">
    @include('superadmin.topbar', ['activeTopLink' => 'status-masjid'])

    <main class="page-content">

      <div class="flex justify-between items-end mb-6">
        <div>
          <h2 class="text-2xl font-bold text-gray-900 tracking-tight">Data Masjid & Musholla</h2>
          <p class="text-gray-500 font-medium mt-1">Inventaris dan status lahan amal usaha tempat ibadah</p>
        </div>
        <div class="flex gap-3">
          <div class="relative">
            <input type="text" placeholder="Cari masjid/musholla..." class="pl-4 pr-4 py-2 bg-white border border-gray-200 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-600 w-64 text-sm">
          </div>
        </div>
      </div>

      @if(session('success'))
        <div class="mb-4 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg font-medium flex items-center gap-2">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          {{ session('success') }}
        </div>
      @endif

      <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <table class="w-full text-left">
          <thead class="bg-gray-50 border-b border-gray-200">
            <tr>
              <th class="p-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Nama Tempat Ibadah</th>
              <th class="p-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Kategori</th>
              <th class="p-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Pengelola</th>
              <th class="p-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-center">Status Lahan</th>
              <th class="p-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-center">Aksi</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-100">

            <tr class="hover:bg-gray-50 transition">
              <td class="p-4 text-sm font-bold text-gray-900">Masjid Raya Al-Falah</td>
              <td class="p-4 text-sm text-gray-600">Masjid</td>
              <td class="p-4 text-sm text-gray-600">PCM Nongsa</td>
              <td class="p-4 text-center">
                <span class="bg-green-100 text-green-800 border border-green-200 text-xs px-2.5 py-1 rounded-md font-bold uppercase tracking-wide">Wakaf Sertifikat</span>
              </td>
              <td class="p-4 text-center">
                <button class="text-green-700 font-semibold text-sm hover:underline">Detail</button>
              </td>
            </tr>

            <tr class="hover:bg-gray-50 transition">
              <td class="p-4 text-sm font-bold text-gray-900">Musholla At-Taqwa</td>
              <td class="p-4 text-sm text-gray-600">Musholla</td>
              <td class="p-4 text-sm text-gray-600">PRM Kibing</td>
              <td class="p-4 text-center">
                <span class="bg-yellow-100 text-yellow-800 border border-yellow-200 text-xs px-2.5 py-1 rounded-md font-bold uppercase tracking-wide">Proses Wakaf</span>
              </td>
              <td class="p-4 text-center">
                <button class="text-green-700 font-semibold text-sm hover:underline">Detail</button>
              </td>
            </tr>

            <tr class="hover:bg-gray-50 transition">
              <td class="p-4 text-sm font-bold text-gray-900">Masjid Baitul Makmur</td>
              <td class="p-4 text-sm text-gray-600">Masjid</td>
              <td class="p-4 text-sm text-gray-600">PCM Batu Aji</td>
              <td class="p-4 text-center">
                <span class="bg-blue-100 text-blue-800 border border-blue-200 text-xs px-2.5 py-1 rounded-md font-bold uppercase tracking-wide">Hak Pakai</span>
              </td>
              <td class="p-4 text-center">
                <button class="text-green-700 font-semibold text-sm hover:underline">Detail</button>
              </td>
            </tr>

          </tbody>
        </table>
      </div>

    </main>
  </div>
</div>
</body>
</html>